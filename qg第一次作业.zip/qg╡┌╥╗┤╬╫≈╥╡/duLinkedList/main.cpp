#include <stdio.h>
#include <stdlib.h>
#include "../head/duLinkedList.hpp" 
#include "duLinkedList.cpp" 

int main(){
	DuLinkedList d;
	DuLNodePtr p,q;
	ElemType *e;
	printf("--------------------\n");
	InitList_DuL(&d);
//	show(d);
	Printdata(d);
	
//	InsertBeforeList_DuL(p, q);//q���뵽pǰ
	
//	InsertAfterList_DuL(p, q);//q���뵽p�� 
	
//	DeleteList_DuL(p, e);
//	printf("--------------------\n");
	TraverseList_DuL(d, Visit);
//	printf("--------------------\n");
	DestroyList_DuL(&d);
//	printf("--------------------\n");
	system("pause");
}
