#ifndef XXX_H
#define XXX_H

typedef int ElemType;
typedef struct DuLNode { 
	ElemType data; 
  	struct DuLNode *prior,  *next; 
} DuLNode, *DuLinkedList;
#define DuLNodePtr DuLinkedList
#define DuLNodeLength sizeof(DuLNode)
#define OVERFLOW -1

typedef enum Status { 
	ERROR,
	SUCCESS, 
} Status;




#endif
