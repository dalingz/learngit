
#ifndef XXX_H
#define XXX_H


typedef int ElemType; 

typedef struct LNode { 
	ElemType data; 
  	struct LNode *next; 
} LNode, *LinkedList;
#define LNodePtr LinkedList
#define LNodeLength sizeof(LNode)
#define OVERFLOW -1
// define Status
typedef enum Status { 
	ERROR,
	SUCCESS
} Status;


Status InitList(LinkedList *L);
void Printdata(LinkedList L);
void DestroyList(LinkedList *L);
Status InsertList(LNode *p, LNode *q);
Status DeleteList(LNode *p, ElemType *e); 
Status SearchList(LinkedList L, ElemType e);
Status ReverseList(LinkedList *L);
Status IsLoopList(LinkedList L);
LNode* FindMidNode(LinkedList *L);
void TraverseList(LinkedList L, void (*visit)(ElemType e));
void show(LNodePtr head);
int LinkedListLength(LinkedList L); 
void Twice(ElemType e);
void Plus(LinkedList L);
void Settle(LinkedList L);
void ExpressMid(LinkedList *L);
LNode* LocatePtr(LinkedList L,ElemType e);


#endif
